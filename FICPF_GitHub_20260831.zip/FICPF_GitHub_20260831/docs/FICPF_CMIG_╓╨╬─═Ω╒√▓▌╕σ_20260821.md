# 冻结归纳校准的病理-组学融合：面向计算病理生存分析的稳健多模态方法

**英文题目：** Frozen Inductively Calibrated Pathomic Fusion for Robust Multimodal Survival Analysis in Computational Pathology

**作者：** [待补充]

**单位：** [待补充]

**通讯作者：** [待补充]

> 稿件状态：面向 *Computerized Medical Imaging and Graphics* 的中文完整初稿。所有实验数值均来自当前锁定结果，核心参考文献已按正式出版信息核对；作者信息、伦理审批、基金、数据再分发许可和匿名仓库地址仍需投稿前确认。

## 摘要

全视野病理图像与分子组学能够提供互补预后证据，但在小样本、高删失队列中，端到端联合模型容易受到模态尺度不一致和弱组学分支负迁移的影响。本文提出冻结归纳校准的病理-组学融合方法（Frozen Inductively Calibrated Pathomic Fusion，FICPF）。该方法保留已训练的 VLSA-CONCH 病理分支，使用签名基因关联的 RNA-seq/CNV、PCA 和 L2 正则 Cox 模型构建轻量组学分支，并在每个外层训练折内将两种模态映射到统一分位数空间。校准后的分数以固定 `0.80/0.20` 权重融合，组学缺失时回退病理。在五个 TCGA 队列的患者级外层五折评估中，FICPF 的宏平均 C-index 为 `0.7050`，高于 matched VLSA 的 `0.6958`，配对增益为 `+0.0092`（95% CI `[0.0016, 0.0169]`），并高于统一复现的 MCAT-CONCH 与 CAT-TPL-CONCH。采用不读取结局的固定分位数阈值时，五个队列的 OOF 高低风险组均显著分离（log-rank `p<0.001`，HR `2.00-5.26`），且在现有临床变量校正后仍显著。FICPF 还将宏平均 IBS 从 `0.2296` 降至 `0.2001`，使 D-calibration 通过折数从 `14/25` 增至 `25/25`，但绝对时间 MAE 变差。结果表明，FICPF 能以很低的增量成本改善风险排序和群体概率校准，并限制弱或缺失组学输入造成的负迁移。

**关键词：** 计算病理；全视野图像；生存分析；视觉语言模型；多模态融合；RNA-seq；模型校准

## 1 引言

癌症预后评估是精准诊疗的重要组成部分。传统生存分析主要依赖临床分期、病理分级和少量分子标志物，但难以充分利用全视野病理图像（whole-slide image，WSI）中丰富的组织形态、细胞组成和肿瘤微环境信息。随着数字病理和深度学习的发展，多实例学习方法能够在缺少像素级标注的条件下，将一张 WSI 中数千个图像块聚合为患者级表示，并用于分型、分级和生存预测。然而，病理图像尺寸巨大、患者数量有限且生存标签包含大量删失，使模型容易过拟合非稳健的局部模式。

病理基础模型和视觉语言模型为这一问题提供了新的表征途径。CONCH 等模型通过大规模病理图文预训练获得具有语义结构的图像特征 [4]，VLSA 则进一步利用有序生存提示词，将 WSI 表征与不同预后等级的语言概念进行匹配 [5]。这类方法兼具较强的病理预测能力和一定的语义可解释性，但其输入仍主要来自病理模态。癌症结局不仅由形态决定，基因表达、拷贝数变化和信号通路状态也可能解释病理图像无法区分的分子异质性。因此，病理-组学联合建模是提升预后预测的重要方向。

现有多模态生存方法通常使用交叉注意力、双线性融合或多模态 Transformer 联合优化病理与组学表示。此类模型具有较强的交互建模能力，但也存在三个实际问题。第一，不同模态的样本规模、噪声和预测尺度差异很大，未经约束的联合训练可能使弱模态破坏已经较强的病理分支。第二，生存队列中的未删失事件数量通常远少于总患者数，高容量融合模块容易产生较大的折间波动。第三，端到端多模态训练增加了显存、调参和复现成本，并且在组学缺失时通常需要额外的补全或缺失模态模型。

本文研究一个更保守的问题：在已经获得可靠 VLSA 病理预测的条件下，能否利用轻量组学证据实现稳定增益，而不重新联合训练病理主干？核心困难不只是学习一个组学风险模型，还在于如何比较和融合两个具有不同量纲、分布和可靠性的预测。基于此，本文提出 FICPF。该方法将病理分支冻结，把 RNA-seq 与拷贝数变异压缩为低维 Cox 生存读出，并通过训练折经验累积分布函数对两个分支进行归纳式尺度对齐。固定的小组学权重用于控制负迁移，显式病理回退则保证组学缺失时仍可完成预测。

本文的主要贡献如下：

1. 提出一种无需联合深度重训练的病理-组学生存融合框架，在保留 VLSA 视觉语言病理分支的同时，引入低成本的患者特异组学证据。
2. 提出训练折归纳分布校准，将病理预测时间和 Cox 组学分数分别映射到各自训练分布的分位数空间，从而减少模态尺度不一致对固定融合的影响。
3. 采用统一的保守融合权重和缺失组学病理回退机制，以降低低事件、弱组学或低覆盖队列中的负迁移风险。
4. 在五个 TCGA 队列上完成同划分、同指标的外层五折验证，并提供端到端多模态对照、组件消融、患者对应关系负对照、参数敏感性、生存曲线评价、组学损坏鲁棒性、复杂度和随机种子稳定性分析。

## 2 相关工作

### 2.1 WSI 多实例生存分析

WSI 通常包含数千至数万个图像块，无法直接以常规图像尺寸输入模型。注意力多实例学习建立了兼顾置换不变性与实例相关性估计的 bag 聚合方式 [12]。CLAM 进一步利用聚类约束实现数据高效的弱监督病理建模 [2]，TransMIL 则使用 Transformer 建模图像块间相关性 [13]。在预后任务中，DeepAttnMISL 将注意力引导的多实例学习与右删失生存目标结合，直接从 WSI 预测患者结局 [14]。这些方法证明了弱监督 WSI 预后的可行性，但图像块冗余、空间异质性、删失标签处理以及患者级样本量不足仍是主要挑战。

### 2.2 病理视觉语言模型与有序生存提示

UNI 与 Prov-GigaPath 等大规模自监督病理编码器提高了图像块和切片表征的迁移能力 [21,22]。病理视觉语言基础模型进一步通过图像-文本监督将组织形态映射到医学语义空间。CONCH 提供了面向计算病理的视觉与文本预训练表示 [4]，VLSA 在此基础上使用从差到好的有序预后提示，并通过视觉语言特征聚合输出离散生存分布 [5]。近期 MPRSurv 又从多视角提示和不确定性感知视觉排序角度扩展了该方向 [20]。与只输出不可解释标量风险的模型相比，提示学习使预测能够与有序预后概念联系起来。本文不改变 VLSA 的图像编码、提示学习和 WSI 聚合过程，而是将其视为冻结的强病理预测器。

### 2.3 病理-组学多模态生存模型

病理与分子测量提供了肿瘤状态的互补视角。Pathomic Fusion 显式建模组织学、细胞图和基因组表征之间的交互 [15]，PORPOISE 随后在 14 种癌症上验证了可解释的图像-组学预后建模 [16]。MCAT 使用通路级组学嵌入作为查询，与 WSI 图像块进行共注意力交互 [3]；MOTCat 通过最优传输引入全局结构一致性 [17]，SURVPATH 建模生物通路与组织学之间的稠密交互 [18]，多模态原型学习则将两种模态压缩为可解释的原型 token [19]。CAT-with-TPL 在交叉注意力基础上进一步引入文本提示学习 [6]，近期泛癌研究还探索了癌种感知专家混合和零样本迁移 [30]。这些端到端方法能够学习非线性跨模态关系，但在组学分支较弱或事件稀疏时可能不稳定。FICPF 研究的是另一种设定：保留强病理模型，以有限容量和有限干扰的归纳晚期融合引入分子信息。

### 2.4 生存风险校准与晚期融合

Cox 比例风险模型利用部分似然处理删失数据，在样本量有限时仍是重要的生存分析工具 [7]。DeepSurv、DeepHit 和离散时间神经生存模型进一步将生存学习扩展到非线性风险函数或直接估计事件时间分布 [23-25]。无论模型类型如何，区分度、概率误差和校准刻画的是不同性质，应采用考虑删失的评价程序分别报告 [27-29]。晚期融合可以在不改变各模态模型的情况下组合预测，但原始风险、概率或预测时间往往不处于统一尺度。FICPF 使用经验分布映射进行非参数尺度对齐，其 StandardScaler、PCA、Cox 模型、经验分布和曲线投影均只在外层训练折内拟合。与根据验证标签或测试分布重新估计融合权重的做法不同，该设计保持了归纳评估契约。

## 3 方法

### 3.1 问题定义与总体框架

对患者 (i)，记其病理图像块特征 bag 为 (X_i^p)，组学向量为 (x_i^o)，观察时间为 (t_i)，事件指示为 (e_i\in\{0,1\})。目标是在右删失条件下预测患者相对生存顺序及完整生存曲线。每个外层折 (k) 包含训练集 \(\mathcal D_k^{train}\) 和测试集 \(\mathcal D_k^{test}\)。测试折只用于最终评价，不参与特征标准化、PCA、Cox 拟合、经验分布估计、融合权重选择或 checkpoint 选择。

FICPF 包含冻结病理分支、紧凑组学分支、训练折归纳校准、保守融合和单调生存曲线重建五个步骤，如图 1 所示。

![图1 FICPF方法总览](../figures/ficpf_20260821/ficpf_method_overview.png)

**图 1. FICPF 方法总览。** matched VLSA-CONCH 提供冻结的病理生存曲线与平均预测时间；组学分支使用签名关联 RNA-seq/CNV、训练折标准化、PCA64 和 L2-Cox。两个模态分别通过训练折经验 CDF 映射到统一分位数空间，并采用固定 `0.80/0.20` 权重融合。组学缺失时回退到病理预测，完整生存曲线由训练折 Cox-Breslow 单调投影得到。

### 3.2 冻结病理生存分支

本文使用同协议复现的 VLSA-CONCH 作为病理主干。每张 WSI 已被转换为 512 维 CONCH 图像块特征，VLFAN 视觉语言聚合模块结合有序生存提示得到患者在离散时间点 \(t_j\) 上的生存曲线：

\[
S_i^p(t_j)=P(T_i>t_j\mid X_i^p).
\]

按照 SurvivalEVAL 的 Mean 预测契约，本文对 \(S_i^p\) 进行线性插值并计算平均预测生存时间 \(T_i^p\)。\(T_i^p\) 越大表示模型预测患者生存越长。FICPF 阶段不修改或联合训练病理网络，直接使用 matched VLSA 的训练折与测试折预测以及原协议 raw last checkpoint。这样可以将最终变化归因于新增的组学读出与校准融合，而不是病理优化策略变化。

### 3.3 紧凑组学生存分支

组学输入由 RNA-seq 与拷贝数变异组成。根据签名表保留六类基因集合：抑癌基因、癌基因、蛋白激酶、细胞分化标志物、转录因子以及细胞因子与生长因子。仅选择表中存在且以 `_rnaseq` 或 `_cnv` 结尾的变量。

对每个外层训练折，首先使用训练患者拟合 StandardScaler，再以 randomized SVD 进行主成分分析（PCA）[26]。实际成分数为

\[
d_k=\min(64,n_k^{train}-1,p_k),
\]

其中 \(p_k\) 是该队列的可用组学变量数。主实验固定 PCA 随机种子为 42。

对降维向量 \(z_i\in\mathbb R^{d_k}\)，使用 L2 正则 Cox 模型计算线性风险 \(\eta_i=w^\top z_i+b\)。优化目标为

\[
\mathcal L_{Cox}=
-\frac{1}{\sum_i e_i}
\sum_{i:e_i=1}
\left[
\eta_i-\log\sum_{j:t_j\ge t_i}\exp(\eta_j)
\right]
+\lambda\frac{\lVert w\rVert_2^2}{d_k}.
\]

本文设置 \(\lambda=0.10\)，使用 Adam 优化 1200 步，学习率为 0.02。为统一两个分支的方向，将组学分数定义为 \(T_i^o=-\eta_i\)，因此 \(T_i^o\) 越大同样表示预测生存越长。

### 3.4 训练折归纳分布校准

病理平均预测时间与组学 Cox 分数具有不同量纲和边际分布，直接相加会使数值范围较大的模态占据主导。对模态 \(m\in\{p,o\}\)，本文仅使用外层训练患者建立经验累积分布：

\[
\widehat F_m^{train}(z)=
\frac{1}{n_k^{train}}
\sum_{j\in\mathcal D_k^{train}}
\mathbb 1(T_j^m\le z).
\]

患者的校准分数为

\[
q_i^p=\widehat F_p^{train}(T_i^p),\qquad
q_i^o=\widehat F_o^{train}(T_i^o).
\]

该映射将两个模态转换为相对于各自训练分布的生存分位数。经验 CDF 单调不减，不会反转模态内部的患者顺序，但有限训练样本可能将相邻测试值映射到同一分位数并引入 ties。测试标签和测试分布均不用于校准。

### 3.5 保守融合与缺失组学回退

FICPF 使用固定凸组合

\[
q_i=(1-\alpha)q_i^p+\alpha q_i^o,\qquad \alpha=0.20.
\]

该权重在所有数据集和外层折中保持一致，不根据队列、验证结果或测试结果调整。选择较小组学权重的目标是：当组学包含与病理互补的信息时允许其调整患者顺序，当组学分支较弱时限制其对强病理预测的破坏。

若患者缺少完整组学输入，则显式设置

\[
q_i=q_i^p,
\]

直接回退到病理预测。该机制不依赖生成式补全或额外缺失模态网络。

### 3.6 单调生存曲线重建

标量 \(q_i\) 可直接用于 C-index 排序。为进一步计算 IBS、D-calibration、KM calibration 和 MAE，本文在外层训练折内构造不改变排序的 Cox-Breslow 曲线投影。首先将训练分位数裁剪到 \([0.5/n_k^{train},1-0.5/n_k^{train}]\)，再定义风险方向特征

\[
u_i=-\log\frac{q_i}{1-q_i}.
\]

在训练折上通过 Cox 部分似然估计正标量 \(\gamma\in[0.05,5]\)，并使用 Breslow 方法估计基线生存函数 \(S_0(t)\) [8]。最终曲线为

\[
S_i^{FICPF}(t)=S_0(t)^{\exp(\gamma u_i)}.
\]

曲线首尾分别固定为 1 和 0，以匹配 VLSA 的有限离散时间支持。由于 \(\gamma>0\) 且变换单调，曲线投影不改变 FICPF 的患者排序。实验中标量与曲线计算的 C-index 最大绝对差为 0。

## 4 实验设置

### 4.1 数据集与患者划分

实验使用 BLCA、BRCA、GBMLGG、LUAD 和 UCEC 五个 TCGA 癌症队列，原始病理、临床和分子数据来自 TCGA，并由美国国家癌症研究所 Genomic Data Commons 按数据访问层级管理和分发 [1]。本研究沿用 VLSA 与 CAT-with-TPL 工程中的患者级生存表和预处理组学表。组学表包含患者生存字段以及基因级 RNA-seq 和拷贝数变异（copy-number variation，CNV）特征；本文依据 CAT-with-TPL 提供的六类基因签名定义，仅保留能够在对应队列表中匹配到的 RNA-seq/CNV 变量。纳入患者必须同时位于锁定外层划分中、具有可用的 matched VLSA 病理预测、有效生存时间与删失状态，并具有完整的签名关联组学记录。所有方法使用相同的患者级 outer 5-fold 划分。表 1 给出汇总后的 out-of-fold 患者数、事件数和签名关联组学变量数。

**表 1. 数据集统计。**

| 数据集 | 患者数 | 事件数 | 事件比例 | 签名组学变量数 |
|---|---:|---:|---:|---:|
| BLCA | 373 | 169 | 0.453 | 3062 |
| BRCA | 956 | 130 | 0.136 | 3189 |
| GBMLGG | 569 | 187 | 0.329 | 2832 |
| LUAD | 453 | 158 | 0.349 | 3096 |
| UCEC | 480 | 75 | 0.156 | 123 |
| 合计 | 2831 | 719 | 0.254 | - |

所有预处理和监督拟合均在每个 outer training fold 内独立执行。主方法不使用早停，也不基于 held-out 标签选择 checkpoint、PCA 维数或融合权重。当前继承的预处理组学表没有保存可唯一追溯的 GDC data release 编号，因此本文以实际输入表、固定划分和逐文件 SHA256 作为数据版本锁定依据；这一限制将在公开仓库的数据说明中明确披露，而不会推断一个无法由现有文件证明的 release 号。

### 4.2 比较方法

本文比较以下方法：

- **Published VLSA：** 原论文在相同五个队列上报告的结果，仅作为非配对参考。
- **Matched VLSA：** 使用当前数据、划分、CONCH 特征和 raw last checkpoint 重新得到的同协议病理基线。
- **MCAT-CONCH：** 将 MCAT 适配到相同 CONCH 病理特征与分子组学表的端到端多模态基线。
- **CAT-TPL-CONCH：** 将 CAT-with-TPL 适配到相同输入和外层划分的文本提示多模态基线。
- **FICPF：** 本文提出的冻结病理、PCA-Cox 组学、训练折 ECDF 和固定保守融合方法。

MCAT-CONCH 和 CAT-TPL-CONCH 的统一复现固定随机种子为 1，训练 20 个 epoch，学习率为 \(10^{-4}\)，梯度累积患者数为 16，采用 weighted sampling、无 early stopping，并使用 final checkpoint。本文报告的是相同 CONCH 输入下的适配结果，而非两篇外部方法原论文使用其他特征编码器时的已发表数值。

### 4.3 评价指标

主要指标为 C-index，统一采用 `SurvivalEVAL_mean_continuous_comparable_all_ties` 契约：以平均预测生存时间作为排序分数，使用 comparable pairs，并将预测 ties 计为 0.5 [27,29]。辅助曲线指标包括 IPCW 加权 IBS [28]、hinge MAE、D-calibration 和 Kaplan-Meier calibration error [9-11]。

统计不确定性通过折内患者级配对 bootstrap 估计。每次在每个 outer fold 内有放回抽样测试患者，重新计算候选方法与参照方法的 C-index 差值，再对五折取平均。本文报告 5000 次重采样的 2.5% 和 97.5% 分位数以及 \(P(\Delta>0)\)。原论文结果缺少逐患者预测，因此不参与配对 bootstrap。

风险分层分析汇总各队列的 OOF 预测。FICPF 校准融合分数为时间方向分数，因此预先将融合分位数低于 `0.50` 的患者定义为高风险，其余定义为低风险。该阈值来自分位数表示的固定中点，不根据生存结局寻优。本文使用 Kaplan-Meier 曲线和双侧 log-rank 检验比较两组，并使用未校正单变量 Cox 模型估计高风险相对低风险的 HR 及其 95% CI。次要完整病例 Cox 分析进一步校正每 10 岁年龄、两个性别组均不少于 10 人时的性别，以及 OncoTree 组织学亚型；不足 20 人的亚型统一合并为 `Other`。`site` 包含 30 个以上稀疏类别，为避免低事件队列过参数化而不纳入。临床关联模型只评价已经生成的 OOF 分数，不参与患者预测。

### 4.4 消融、敏感性与鲁棒性实验

组件消融包括 pathology-only、omics-only、未校准固定融合、ECDF 等权融合和完整 FICPF。患者对应关系负对照在每个测试折内随机打乱组学预测 1000 次，且打乱不读取生存标签。融合权重敏感性报告 \(\alpha\in\{0,0.1,0.2,0.3,0.5\}\)，PCA 敏感性报告 16、32、64 和 128 个请求成分。这些结果只用于描述稳定区间，不替换已经锁定的主配置。为区分组学降维随机性与深度病理主干训练随机性，另使用训练种子 `42、3404、3405` 完整训练 75 个 matched VLSA 模型（3 个种子 × 5 个队列 × 5 个 outer fold），再固定组学 PCA/Cox 种子为 42、固定全部 FICPF 超参数进行重评估。该实验不依据 outer test 结果选择种子或调整融合权重。

组学损坏实验包括：随机特征缺失并使用训练均值填补；在训练标准化空间加入零均值高斯噪声；随机患者整模态缺失并回退病理。每个随机条件重复 20 次，模型与训练统计不因测试扰动重新拟合。

### 4.5 软件、硬件与可复现性

Matched VLSA、MCAT-CONCH 和 CAT-TPL-CONCH 的深度模型实验在单张 NVIDIA GeForce RTX 3090 24 GB GPU 上完成；云端训练环境为 Python 3.8.10、PyTorch 2.4.1 和 CUDA 12.1。该设置没有使用双卡数据并行。FICPF 的 StandardScaler、PCA、Cox 拟合、ECDF 映射、bootstrap 和曲线评价均为轻量增量分析，其中 PCA-Cox 拟合在 CPU 上运行，不需要额外 GPU 训练。

清理后的分析包已在 Python 3.10.20 环境复核，关键版本为 NumPy 1.26.4、pandas 2.3.3、SciPy 1.15.3、scikit-learn 1.7.2、PyYAML 6.0.3、Matplotlib 3.10.9 和 PyTorch 2.12.0.dev20260408+cu128。正式 FICPF 配置固定 PCA 随机种子为 42、PCA 请求维数为 64、Cox L2 系数为 0.10、病理/组学权重为 0.80/0.20，并使用 5000 次患者级配对 bootstrap。外部多模态基线固定随机种子为 1。冻结发布包包含实际分析输入、逐患者预测、固定划分、脚本、环境清单和 SHA256 manifest；原始 WSI、CONCH 权重、WSI patch 特征及 VLSA checkpoint 作为上游依赖单独管理。

## 5 结果

### 5.1 五数据集主要结果

表 2 给出五数据集统一 outer 5-fold C-index。FICPF 在五个数据集上均取得最高平均值。其宏平均为 `0.705017`，高于 Published VLSA 的 `0.695420` 和 matched VLSA 的 `0.695782`。相对 matched VLSA 的宏平均增益为 `+0.009235`。

**表 2. 五数据集统一 C-index 比较。**

| 数据集 | Published VLSA | Matched VLSA | MCAT-CONCH | CAT-TPL-CONCH | FICPF |
|---|---:|---:|---:|---:|---:|
| BLCA | 0.617600 | 0.617974 | 0.621436 | 0.626311 | **0.633366** |
| BRCA | 0.665200 | 0.667613 | 0.583414 | 0.608419 | **0.667881** |
| GBMLGG | 0.800200 | 0.800470 | 0.791838 | 0.810900 | **0.818217** |
| LUAD | 0.637000 | 0.635636 | 0.607664 | 0.606663 | **0.643830** |
| UCEC | 0.757100 | 0.757216 | 0.643184 | 0.654907 | **0.761791** |
| **宏平均** | **0.695420** | **0.695782** | **0.649507** | **0.661440** | **0.705017** |

![图2 五数据集统一比较](../figures/ficpf_20260821/ficpf_main_comparison.png)

**图 2. 五数据集统一外层五折比较。** 左图比较已发表 VLSA 参考、matched VLSA、MCAT-CONCH、CAT-TPL-CONCH 与 FICPF；右图给出 FICPF 相对 matched VLSA 的患者级配对 bootstrap 差值和 95% CI。

FICPF 在 25 个外层折中有 18 折高于 matched VLSA。宏平均配对增益的 95% CI 为 `[0.001602, 0.016864]`，\(P(\Delta>0)=0.9928\)。队列层面，BLCA 提高 `+0.015392`，95% CI 为 `[0.000690, 0.029861]`；GBMLGG 提高 `+0.017746`，95% CI 为 `[0.009573, 0.026521]`，两者区间排除零。LUAD 五折全部正向，平均提高 `+0.008194`，但区间 `[-0.006905, 0.023660]` 仍跨零。BRCA 和 UCEC 分别只提高 `+0.000268` 与 `+0.004575`，不支持队列级显著领先。

### 5.2 与端到端多模态方法的比较

MCAT-CONCH 和 CAT-TPL-CONCH 的宏平均分别为 `0.649507` 和 `0.661440`。FICPF 相对两者分别提高 `+0.055510` 和 `+0.043577`，配对 95% CI 分别为 `[0.027766, 0.082926]` 和 `[0.017379, 0.070992]`。在 BRCA 与 UCEC 上，两种端到端融合方法均明显低于 matched VLSA，而 FICPF 基本保持或小幅改善病理结果。这说明在低事件队列中，冻结强病理分支并限制组学权重能够降低联合训练造成的负迁移。

该结果不表示端到端多模态方法普遍无效。CAT-TPL-CONCH 在 BLCA 和 GBMLGG 上仍高于 matched VLSA，且在 GBMLGG 达到 `0.810900`。FICPF 的结论应限定为当前五个 TCGA 队列、CONCH 输入和统一训练协议下的稳健性优势。

### 5.3 组件消融

表 3 显示，组学单模态宏平均只有 `0.627302`，比病理单模态低 `0.068479`。直接以相同 `0.80/0.20` 权重融合未校准分数仅得到 `0.697199`，相对病理提高 `+0.001418`，95% CI 跨零。完整 FICPF 达到 `0.705017`，比未校准固定融合进一步提高 `+0.007817`，95% CI 为 `[0.001065, 0.015152]`。因此，新增组学本身不能解释最终增益，训练折尺度对齐是关键组成部分。

**表 3. FICPF 组件消融。**

| 方法 | BLCA | BRCA | GBMLGG | LUAD | UCEC | 宏平均 |
|---|---:|---:|---:|---:|---:|---:|
| Pathology-only | 0.617974 | 0.667613 | 0.800470 | 0.635636 | 0.757216 | 0.695782 |
| Omics-only | 0.615056 | 0.568457 | 0.805108 | 0.580893 | 0.566998 | 0.627302 |
| 未校准固定融合 | 0.620686 | 0.667612 | 0.802314 | 0.634584 | 0.760802 | 0.697199 |
| ECDF 等权融合 | **0.645340** | 0.652083 | **0.834639** | 0.637487 | 0.724637 | 0.698837 |
| FICPF | 0.633366 | **0.667881** | 0.818217 | **0.643830** | **0.761791** | **0.705017** |

等权 ECDF 融合在 BLCA 与 GBMLGG 上取得更高峰值，但在 BRCA 与 UCEC 上出现明显下降。FICPF 的固定保守权重牺牲部分强组学队列的最大增益，以获得更稳定的跨队列表现。

### 5.4 患者对应关系负对照

随机打乱测试患者的组学预测后，BLCA、GBMLGG、LUAD 和 UCEC 的平均 C-index 分别比真实配对低 `0.021094、0.028558、0.012325、0.017507`；随机打乱达到或超过真实 FICPF 的概率分别为 `0.001、<0.001、0.015、0.031`。BRCA 的该概率为 `0.164`，与其主结果中组学增益接近零一致。由此可见，多数队列的改进来自患者特异组学对应关系，而不是向病理分数加入具有固定边际分布的随机平滑项。

### 5.5 固定超参数敏感性

融合权重 \(\alpha=0、0.1、0.2、0.3、0.5\) 的宏平均 C-index 分别为 `0.695659、0.700674、0.705017、0.705861、0.698837`。`0.10-0.30` 形成相对稳定的平台。尽管观察外层测试后发现 \(\alpha=0.30\) 比锁定值高 `0.000844`，本文不据此事后修改主配置；等权融合则会明显降低 BRCA 与 UCEC。

在统一数值环境下重新拟合时，PCA16、PCA32、PCA64 和 PCA128 的宏平均分别为 `0.699804、0.700360、0.705320、0.698368`。不同队列的最优维数并不一致，而 PCA64 是统一维数网格中的最佳跨队列折中。该实验中的 PCA64 与正式主结果相差 `0.000303`，因此只用于趋势分析，不替换表 2 的锁定数值。

![图3 组件消融和敏感性](../figures/ficpf_20260821/ficpf_ablation_sensitivity.png)

**图 3. 组件消融与固定参数敏感性。** 展示主要组件、融合权重和 PCA 维数的宏平均结果。菱形表示锁定的 \(\alpha=0.20\) 和 PCA64。

### 5.6 生存曲线质量

训练折 Cox-Breslow 投影没有改变 FICPF 排序。宏平均 IBS 从 matched VLSA 的 `0.229578` 降低到 `0.200082`，五个队列均得到改善。D-calibration 通过折数从 `14/25` 提高到 `25/25`，宏平均 KM calibration error 从 `0.028292` 降至 `0.017805`。这些结果说明 FICPF 不仅改善排序，还提高了群体层面的概率校准。

然而，hinge MAE 从 `25.23` 个月增加到 `29.89` 个月，五个队列均未改善，平均变差 `4.66` 个月。当前 FICPF 更适合解释为风险排序与分布校准方法，而不能宣称其提高了个体绝对生存时间预测精度。

![图4 生存曲线质量](../figures/ficpf_20260821/ficpf_survival_curve_quality.png)

**图 4. 生存曲线质量的多指标比较。** 展示 matched VLSA 与 FICPF 在五个队列上的 IBS、Kaplan-Meier calibration error、hinge MAE 以及通过 D-calibration 的折数。箭头标示各指标的优选方向。FICPF 改善概率误差和群体校准，但绝对时间 MAE 变差。

### 5.7 组学缺失与噪声鲁棒性

鲁棒性分析使用统一运行时重新拟合的 clean FICPF，其宏平均为 `0.705320`，同运行时病理校准基线为 `0.695659`。50% 随机特征缺失、标准化空间 \(\sigma=0.50\) 高斯噪声和 50% 患者整模态缺失时，宏平均分别为 `0.698259、0.701945、0.698712`，仍比病理高 `0.002600、0.006286、0.003053`。当 100% 患者缺少组学时，显式回退按定义完全恢复病理结果。

![图5 组学损坏鲁棒性](../figures/ficpf_20260821/ficpf_omics_robustness.png)

**图 5. 测试时组学损坏鲁棒性。** 分别展示随机特征缺失、高斯噪声和患者级组学缺失条件下相对病理的 C-index 增益。黑线表示五队列等权宏平均。

队列级结果显示，BLCA、GBMLGG 和 LUAD 在较强扰动下仍保留正收益；BRCA 因 clean 增益接近零而围绕病理波动。UCEC 只有 123 个签名关联变量，50% 特征缺失和 \(\sigma=0.50\) 噪声下分别低于病理 `0.014065` 和 `0.011553`。因此，固定保守融合在宏平均和高覆盖队列中具有一定鲁棒性，但不能保证低覆盖组学遭受严重特征损坏时仍不退化。实际应用中应检测整模态缺失并执行病理回退。

### 5.8 随机种子稳定性与计算复杂度

固定所有输入与超参数，仅将 randomized PCA 的种子设为 `0、1、42、3404、3405`，所得宏平均范围为 `0.703921-0.705320`，标准差为 `0.000572`，总范围为 `0.001398`。最差种子仍比正式 matched VLSA 高 `0.008139`，说明组学 PCA-Cox 分支的数值随机性不足以解释主增益。

进一步固定组学 PCA/Cox 种子为 42，对三个完整 matched VLSA 训练种子进行重评估（表 4）。三个种子的病理宏平均分别为 `0.695782、0.686299、0.679618`，加入 FICPF 后分别达到 `0.705260、0.699637、0.693682`，对应增益为 `+0.009479、+0.013338、+0.014064`。跨种子平均由 `0.687233±0.006632` 提高到 `0.699527±0.004727`，平均增益为 `+0.012294±0.002012`。15 个“训练种子 × 队列”点估计全部为正；跨种子平均增益在 BLCA、BRCA、GBMLGG、LUAD 和 UCEC 分别为 `+0.017772、+0.004174、+0.019307、+0.012535、+0.007679`。BLCA 和 GBMLGG 在三个种子下的患者级配对 95% CI 均排除零，其余队列虽然点估计一致为正，但部分区间跨零，因此不将 15/15 正向解释为 15/15 均达到统计显著。seed 42 的同运行时重拟合与已保存 PCA64 复现表的最大队列均值差为 `0.000343`，低于预先沿用的 `0.001` 数值复现容差；正式锁定主表仍保持不变。

**表 4. 完整病理主干训练种子稳定性。** 组学模型、PCA/Cox 种子、outer folds、融合权重和其他超参数均固定。

| VLSA 训练种子 | 病理宏平均 | FICPF 宏平均 | 增益 | 正向队列 |
|---:|---:|---:|---:|---:|
| 42 | 0.695782 | 0.705260 | +0.009479 | 5/5 |
| 3404 | 0.686299 | 0.699637 | +0.013338 | 5/5 |
| 3405 | 0.679618 | 0.693682 | +0.014064 | 5/5 |
| 三种子均值±SD | 0.687233±0.006632 | 0.699527±0.004727 | +0.012294±0.002012 | 15/15 组合 |

FICPF 不增加深度可训练参数。PCA64 后的 Cox 读出每折只有 64 个权重和 1 个偏置。25 折增量 CPU 拟合总时间为 `21.145 s`，平均每折 `0.846 s`；最小持久状态平均约为 `1.262 MB`（float64），增量 CPU 推理时间平均为 `0.0149 ms/患者`。该统计不包括已有 VLSA 推理、WSI 特征提取和 RNA/CNV 数据获取成本。

### 5.9 固定阈值 OOF 风险分层

不进行结局驱动阈值寻优时，固定 `0.50` 分位数阈值仍在五个队列中分离出显著不同的 OOF 高低风险组，所有 log-rank `p<0.001`。高风险相对低风险的未校正 HR 在 BLCA 为 `2.00`（95% CI `1.46-2.74`），BRCA 为 `2.65`（`1.82-3.87`），GBMLGG 为 `5.26`（`3.72-7.44`），LUAD 为 `2.20`（`1.57-3.09`），UCEC 为 `3.56`（`2.09-6.06`）。校正现有年龄、性别和组织学亚型后，五队列风险组仍全部显著，校正 HR 为 `1.84-2.92`（表 5）。其中 GBMLGG 从未校正 `5.26` 降至 `2.36`，说明年龄和组织学亚型解释了部分风险差异，但不能完全解释 FICPF 的分层结果。

**表 5. 固定阈值风险分层与现有临床变量校正。** 表中未校正结果与校正结果使用相同的完整病例子集；末列为 FICPF 风险组系数的 Wald 检验。

| 队列 | 完整病例 | 事件 | 未校正 HR（95% CI） | 校正 HR（95% CI） | 校正 p |
|---|---:|---:|---:|---:|---:|
| BLCA | 373 | 169 | 2.00（1.46-2.74） | 1.84（1.34-2.52） | <0.001 |
| BRCA | 956 | 130 | 2.65（1.82-3.87） | 2.75（1.87-4.04） | <0.001 |
| GBMLGG | 569 | 187 | 5.26（3.72-7.44） | 2.36（1.57-3.52） | <0.001 |
| LUAD | 443 | 155 | 2.08（1.48-2.93） | 2.14（1.52-3.01） | <0.001 |
| UCEC | 478 | 75 | 3.59（2.11-6.11） | 2.92（1.68-5.07） | <0.001 |

![图6 固定阈值 OOF 风险分层](../figures/ficpf_20260821/ficpf_oof_km_risk_stratification.png)

**图 6. 固定阈值 OOF 风险分层。** （A-E）五个 TCGA 队列的高低风险 Kaplan-Meier 曲线。每名患者均由训练时未包含该患者的外层模型产生预测；融合分位数低于 `0.50` 定义为高风险，阈值不使用生存结局寻优，曲线上标出删失。（F）高风险相对低风险的未校正与临床校正 Cox HR 及 95% CI。校正变量包括年龄、可辨识性别和样本量充分的 OncoTree 组织学亚型，校正结果采用完整病例。

## 6 讨论

### 6.1 为什么训练折分布校准有效

FICPF 的主要提升不是来自更复杂的网络，而是来自对融合对象的重新定义。VLSA 的平均预测时间由离散生存曲线和队列时间网格决定，Cox 组学分支输出的则是对数风险，两者不存在可直接比较的数值尺度。未经校准的固定融合只能带来 `+0.0014` 的宏平均提升。训练折 ECDF 将两个分支都转换为相对于各自训练分布的位置，使固定权重表示“患者排序贡献比例”而非“原始数值幅度比例”。完整 FICPF 相对未校准融合的显著增益支持这一解释。

经验 CDF 仍是一种阶梯函数，可能引入 ties，而不是严格保持所有 C-index 数值不变。当前审计显示，单模态校准导致的 C-index 最大变化约为 `0.0021`，且没有顺序反转。未来可考虑训练折内的平滑分位数映射，但必须在独立开发数据上确定，不能根据当前 outer test 再选择。

### 6.2 保守融合与负迁移控制

组学单模态在 BRCA、LUAD 和 UCEC 上明显弱于病理，但在 GBMLGG 上略高于病理。这种队列差异使统一等权融合并不可靠。固定 `0.20` 组学权重允许组学调整病理排序，同时限制弱组学造成的破坏。权重敏感性表明 `0.10-0.30` 是相对稳定区间，说明主结果不依赖单个精确点；但不同队列的最佳权重差异仍然存在。

与 MCAT-CONCH 和 CAT-TPL-CONCH 的结果相比，FICPF 在 BRCA 和 UCEC 的优势主要来自保持强病理分支，而不是组学分支本身取得高性能。这一结果强调：在事件数较少的生存任务中，多模态方法的价值不仅是提高上限，还包括防止新增模态引发负迁移。

### 6.3 计算与部署意义

FICPF 可直接复用已经保存的 VLSA 预测和预提取 CONCH 特征，不需要重新提取 WSI 图像块，也不需要在 GPU 上联合训练大型多模态模型。新增监督参数只有每折 65 个 Cox 参数，适合计算资源有限的研究环境。显式病理回退也使模型能够在缺少组学的患者上继续运行。

这种低增量成本不代表完整系统成本可以忽略。真实部署仍需要病理切片数字化、组织区域处理、CONCH 特征提取以及标准化的 RNA-seq/CNV 测量。当前复杂度结果只描述在病理预测和组学表已经可用时的附加开销。

### 6.4 局限性

本文存在以下限制。

1. 所有实验均来自 TCGA 回顾性队列，尚未在独立医院或前瞻性队列上验证，数据处理流程和患者构成的域偏移可能影响泛化。
2. 完整病理主干稳定性实验只覆盖三个训练种子。该实验表明 15 个“种子 × 队列”点估计均为正，但每个种子内部的患者级 bootstrap 不等同于对训练过程进行重采样，三种子标准差也不足以构成精确的训练随机性置信区间。
3. BRCA 相对 matched VLSA 几乎没有增益，UCEC 在严重特征损坏时出现负迁移，说明分子信息的价值依赖队列和组学覆盖。
4. Cox 组学读出采用比例风险假设和线性低维风险函数，可能遗漏非线性、时间变化或通路交互效应。本文选择该结构是为了在低事件条件下控制容量，而非证明其为最优组学模型。
5. FICPF 改善 C-index、IBS 和群体校准，但绝对时间 MAE 变差。当前 Cox-Breslow 投影不适合被解释为精确的个体生存月份预测器。
6. Published VLSA 仅有汇总值，无法进行逐患者配对统计；MCAT-CONCH 和 CAT-TPL-CONCH 是在统一 CONCH 输入下的适配复现，不能替代其原论文其他特征设置的结果。
7. 多个队列级区间和辅助实验没有进行多重比较校正。主要统计结论应以预设的五数据集宏平均比较为中心，队列级结果作为探索性证据。临床校正仅包含年龄、性别和现有 OncoTree 组织学亚型；由于缺少分期与治疗变量，仍不能证明 FICPF 独立于完整临床预后模型。

未来工作应优先验证独立队列泛化、将完整病理主干稳定性扩展到更多训练种子，并在预先划分的开发队列中研究可解释的训练折可靠性估计，使组学权重能够根据数据质量调整而不接触最终测试标签。还可进一步研究兼顾排序、校准和绝对时间误差的曲线投影方法。

## 7 结论

本文提出 FICPF，一种面向计算病理生存分析的冻结归纳校准病理-组学融合框架。该方法保留 VLSA-CONCH 的视觉语言病理预测，利用轻量 PCA-Cox 提取 RNA-seq/CNV 生存信息，并通过训练折经验分布对齐与固定保守权重实现患者级融合。在五个 TCGA 队列上，FICPF 将 matched VLSA 的宏平均 C-index 从 `0.6958` 提高到 `0.7050`，配对置信区间排除零，并优于两个统一复现的端到端多模态基线。三个完整病理训练种子下，15 个“种子 × 队列”点估计全部正向，跨种子宏平均增益为 `+0.0123`。消融和组学打乱实验表明，尺度校准与患者特异分子对应关系是主要增益来源。该方法计算开销低、支持组学缺失时回退病理，但其绝对生存时间 MAE、低覆盖组学鲁棒性和外部泛化仍需改进。总体而言，FICPF 为已经具备强病理模型的场景提供了一种防泄漏、低成本且较稳健的多模态扩展方案。

## 数据与代码可用性

TCGA 病理图像、临床生存信息及分子组学数据可根据相应访问层级通过 NCI Genomic Data Commons（https://gdc.cancer.gov/）获取 [1]。本研究使用的组学输入为 CAT-with-TPL 工程提供的预处理 RNA-seq/CNV 表和六类基因签名定义。由于该继承表未记录可唯一追溯的 GDC release 编号，匿名仓库将提供实际输入文件或在再分发受限时提供其 SHA256、字段说明和获取/预处理说明。本文 FICPF 实现、固定外层划分、逐患者预测、统计分析脚本、绘图脚本和环境 manifest 已整理为独立冻结包；原始 WSI、CONCH 权重、WSI patch 特征和 VLSA checkpoint 不包含在该分析包中。VLSA、CONCH、MCAT 和 CAT-with-TPL 的正式来源见参考文献 [3-6]。匿名审稿仓库地址为 `[待补充]`。

## 伦理声明

本研究仅使用去标识化的公开 TCGA 数据，不涉及新招募受试者或临床干预。是否需要机构伦理豁免及其编号应根据作者所在单位要求补充为 `[待补充]`。

## 利益冲突声明

作者声明不存在利益冲突。`[需由全体作者最终确认]`

## 资金支持

`[待补充基金名称、项目编号及资助方角色]`

## 作者贡献

`[待按 CRediT taxonomy 补充 Conceptualization、Methodology、Software、Validation、Formal analysis、Writing、Supervision 等贡献]`

## 参考文献

1. Cancer Genome Atlas Research Network, Weinstein JN, Collisson EA, Mills GB, Shaw KRM, Ozenberger BA, et al. The Cancer Genome Atlas Pan-Cancer analysis project. *Nature Genetics*. 2013;45:1113-1120. doi:10.1038/ng.2764.
2. Lu MY, Williamson DFK, Chen TY, Chen RJ, Barbieri M, Mahmood F. Data-efficient and weakly supervised computational pathology on whole-slide images. *Nature Biomedical Engineering*. 2021;5:555-570. doi:10.1038/s41551-020-00682-w.
3. Chen RJ, Lu MY, Weng WH, Chen TY, Williamson DFK, Manz T, et al. Multimodal co-attention transformer for survival prediction in gigapixel whole slide images. In: *Proceedings of the IEEE/CVF International Conference on Computer Vision (ICCV)*. 2021:4015-4025.
4. Lu MY, Chen B, Williamson DFK, et al. A visual-language foundation model for computational pathology. *Nature Medicine*. 2024;30:863-874. doi:10.1038/s41591-024-02856-4.
5. Liu P, Ji L, Gou J, Fu B, Ye M. Interpretable vision-language survival analysis with ordinal inductive bias for computational pathology. In: *The Thirteenth International Conference on Learning Representations (ICLR)*. 2025. OpenReview: https://openreview.net/forum?id=trj2Jq8riA.
6. Wang P. Cross-attention transformer with textual prompt learning for survival prediction. In: *Pattern Recognition and Computer Vision*. Lecture Notes in Computer Science, vol. 16285. Singapore: Springer; 2026:293-306. doi:10.1007/978-981-95-5631-1_21.
7. Cox DR. Regression models and life-tables. *Journal of the Royal Statistical Society: Series B (Methodological)*. 1972;34(2):187-202. doi:10.1111/j.2517-6161.1972.tb00899.x.
8. Lin DY. On the Breslow estimator. *Lifetime Data Analysis*. 2007;13:471-480. doi:10.1007/s10985-007-9048-y.
9. Haider H, Hoehn B, Davis S, Greiner R. Effective ways to build and evaluate individual survival distributions. *Journal of Machine Learning Research*. 2020;21(85):1-63.
10. Qi SA, Sun W, Greiner R. SurvivalEVAL: A comprehensive open-source Python package for evaluating individual survival distributions. *Proceedings of the AAAI Symposium Series*. 2024;2(1):453-457. doi:10.1609/aaaiss.v2i1.27713.
11. Kaplan EL, Meier P. Nonparametric estimation from incomplete observations. *Journal of the American Statistical Association*. 1958;53(282):457-481. doi:10.1080/01621459.1958.10501452.
12. Ilse M, Tomczak JM, Welling M. Attention-based deep multiple instance learning. In: *Proceedings of the 35th International Conference on Machine Learning*. PMLR. 2018;80:2127-2136.
13. Shao Z, Bian H, Chen Y, Wang Y, Zhang J, Ji X, Zhang Y. TransMIL: Transformer based correlated multiple instance learning for whole slide image classification. *Advances in Neural Information Processing Systems*. 2021;34:2136-2147.
14. Yao J, Zhu X, Jonnagaddala J, Hawkins N, Huang J. Whole slide images based cancer survival prediction using attention guided deep multiple instance learning networks. *Medical Image Analysis*. 2020;65:101789. doi:10.1016/j.media.2020.101789.
15. Chen RJ, Lu MY, Wang J, Williamson DFK, Rodig SJ, Lindeman NI, Mahmood F. Pathomic Fusion: An integrated framework for fusing histopathology and genomic features for cancer diagnosis and prognosis. *IEEE Transactions on Medical Imaging*. 2022;41(4):757-770. doi:10.1109/TMI.2020.3021387.
16. Chen RJ, Lu MY, Williamson DFK, Chen TY, Lipkova J, Noor Z, et al. Pan-cancer integrative histology-genomic analysis via multimodal deep learning. *Cancer Cell*. 2022;40(8):865-878.e6. doi:10.1016/j.ccell.2022.07.004.
17. Xu Y, Chen H. Multimodal optimal transport-based co-attention transformer with global structure consistency for survival prediction. In: *Proceedings of the IEEE/CVF International Conference on Computer Vision*. 2023:21241-21251.
18. Jaume G, Vaidya A, Chen RJ, Williamson DFK, Liang PP, Mahmood F. Modeling dense multimodal interactions between biological pathways and histology for survival prediction. In: *Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition*. 2024:11579-11590.
19. Song AH, Chen RJ, Jaume G, Vaidya AJ, Baras A, Mahmood F. Multimodal prototyping for cancer survival prediction. In: *Proceedings of the 41st International Conference on Machine Learning*. PMLR. 2024;235:46050-46073.
20. Zhang R, Liu S, Fang M, Zhao S, Guo W, Wang Z, et al. MPRSurv: Multi-perspective prompted ranking for vision-language survival analysis on whole slide images. *Pattern Recognition*. 2026;179:113695. doi:10.1016/j.patcog.2026.113695.
21. Chen RJ, Ding T, Lu MY, Williamson DFK, Jaume G, Song AH, et al. Towards a general-purpose foundation model for computational pathology. *Nature Medicine*. 2024;30:850-862. doi:10.1038/s41591-024-02857-3.
22. Xu H, Usuyama N, Bagga J, Zhang S, Rao R, Naumann T, et al. A whole-slide foundation model for digital pathology from real-world data. *Nature*. 2024;630:181-188. doi:10.1038/s41586-024-07441-w.
23. Katzman JL, Shaham U, Cloninger A, Bates J, Jiang T, Kluger Y. DeepSurv: Personalized treatment recommender system using a Cox proportional hazards deep neural network. *BMC Medical Research Methodology*. 2018;18:24. doi:10.1186/s12874-018-0482-1.
24. Lee C, Zame W, Yoon J, van der Schaar M. DeepHit: A deep learning approach to survival analysis with competing risks. *Proceedings of the AAAI Conference on Artificial Intelligence*. 2018;32(1):2314-2321. doi:10.1609/aaai.v32i1.11842.
25. Gensheimer MF, Narasimhan B. A scalable discrete-time survival model for neural networks. *PeerJ*. 2019;7:e6257. doi:10.7717/peerj.6257.
26. Jolliffe IT, Cadima J. Principal component analysis: A review and recent developments. *Philosophical Transactions of the Royal Society A*. 2016;374(2065):20150202. doi:10.1098/rsta.2015.0202.
27. Harrell FE Jr, Lee KL, Mark DB. Multivariable prognostic models: Issues in developing models, evaluating assumptions and adequacy, and measuring and reducing errors. *Statistics in Medicine*. 1996;15(4):361-387. doi:10.1002/(SICI)1097-0258(19960229)15:4<361::AID-SIM168>3.0.CO;2-4.
28. Graf E, Schmoor C, Sauerbrei W, Schumacher M. Assessment and comparison of prognostic classification schemes for survival data. *Statistics in Medicine*. 1999;18(17-18):2529-2545. doi:10.1002/(SICI)1097-0258(19990915/30)18:17/18<2529::AID-SIM274>3.0.CO;2-5.
29. Uno H, Cai T, Pencina MJ, D'Agostino RB, Wei LJ. On the C-statistics for evaluating overall adequacy of risk prediction procedures with censored survival data. *Statistics in Medicine*. 2011;30(10):1105-1117. doi:10.1002/sim.4154.
30. Zhang B, Li S, Jian J, Ren X, Zhao Z, Guo L, et al. From single-cancer to pan-cancer prognosis: A multimodal deep learning framework for survival analysis with robust generalization capability. *American Journal of Pathology*. 2025;195(10):1869-1884. doi:10.1016/j.ajpath.2025.06.006.

---

## 投稿前内部检查清单

- [ ] 补充作者、单位、通讯作者、基金和伦理信息。
- [x] 核对核心参考文献作者、题名、年份、卷期、页码和 DOI。
- [x] 明确患者纳入条件、组学预处理来源与当前数据版本追溯边界。
- [ ] 将中文稿翻译并整合为 CMIG 英文 LaTeX/Word 模板。
- [ ] 将表 1-3 转换为期刊格式，图片优先使用 PDF 或 SVG。
- [ ] 在最终稿中统一 `outer fold`、`test fold`、`validation` 和 `held-out` 术语。
- [ ] 补充完整代码仓库地址；硬件、软件版本和随机性设置已写入正文。
- [x] 完成三个训练种子、五队列、外层五折的完整 VLSA 主干稳定性实验，并固定组学种子重评估 FICPF。
- [ ] 对所有数据集级探索性比较明确标注未进行多重校正。
- [ ] 检查摘要、结果和结论没有将 MAE 退化或 UCEC 鲁棒性边界遗漏。
